import math
x=float(input())
print(math.floor(x),math.ceil(x), int(x))