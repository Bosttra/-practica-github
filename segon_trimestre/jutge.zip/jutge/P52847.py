x=input().split(" ")
x=[int(z) for z in x]
print(max(x))