x=input()
if x.islower():
    print(x.upper())
else:
    print(x.lower())