llista=input()
x=llista.split(" ")
print(x[2],x[1],x[0])