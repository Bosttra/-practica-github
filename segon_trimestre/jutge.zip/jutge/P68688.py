input()
print("Hello world!")