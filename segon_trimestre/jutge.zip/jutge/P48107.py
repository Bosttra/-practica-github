x=input().split(" ")
x=[int(i) for i in x]
print(int(x[0]/x[1]), int(x[0]%x[1]))