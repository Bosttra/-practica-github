llista=[1,1,2,3,2,1,6,7,1]
sinduplicados=list(set(llista))
#set es per ordenar en un conjunt{} els valors d'una llista, treu els repetits
#list es per converteir un conjunt a una lista
print(sinduplicados)