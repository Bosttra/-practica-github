#73. Diseña un programa que compruebe si los valores de la lista1 (casa,mesa,sal,sol,agua) están 
#repetidos o no en la lista2 (casa,luz,tres,tren,sol,pan). Haz que permita visualizar que palabras se 
#repiten y cuales no
lista1=["casa","mesa","sal","sol","agua"]
lista2=["casa","luz","tres","tren","sol","pan"]
repetits=[]
norepetides=[]
for x in lista2:
    if x in lista1:
        repetits.append(x)
    else: 
        norepetides.append(x)
print("les paraules repetides son: ",repetits)
print("les paraules que no esta repetides de la llista dos son:", norepetides)