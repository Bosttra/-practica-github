llista=[1,2,3,4]
#pot contenir diferents tipos de variables
lista_vuida=[]
llista_mixta=[1,"hola","asa"]
llista_ambllista=[llista_mixta]
print(llista[0])#es el primer variable de la llista
print(llista[-1])#ultims elements
print(llista[1:3])#variable entre aquestes posicions posicio 
#similitud amb metodes strings
